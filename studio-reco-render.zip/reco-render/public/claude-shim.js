/* OpenMedias – remplace les fonctions fournies par claude.ai (window.claude.use)
   par des appels au serveur Render. Chargé avant le script de la page. */
(function () {
  "use strict";
  var H = {"X-OM": "1"};
  function fail(r) {
    return r.json().catch(function () { return {}; }).then(function (j) {
      var e = new Error(j.message || ("HTTP " + r.status));
      e.code = j.code || (r.status === 429 ? "rate_limited" : r.status === 401 || r.status === 403 ? "not_granted" : "internal");
      throw e;
    });
  }
  function call(url, opt) {
    opt = opt || {};
    opt.credentials = "same-origin";
    opt.headers = Object.assign({}, H, opt.headers || {});
    return fetch(url, opt).then(function (r) { return r.ok ? r : fail(r); });
  }

  var sample = {
    json: function (prompt, o) {
      return call("/api/sample", {method: "POST", headers: {"Content-Type": "application/json"},
        body: JSON.stringify({prompt: String(prompt || ""), modelTier: (o && o.modelTier) || "default"})})
        .then(function (r) { return r.json(); }).then(function (j) { return j.data; });
    }
  };

  var downloads = {
    save: function (o) {
      var blob = o.data instanceof Blob ? o.data : new Blob([o.data]);
      var url = URL.createObjectURL(blob), a = document.createElement("a");
      a.href = url; a.download = o.filename || "document"; a.style.display = "none";
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(url); }, 30000);
      return Promise.resolve({ok: true});
    }
  };

  var db = {
    doc: function (path) {
      var url = "/api/doc/" + String(path).split("/").map(encodeURIComponent).join("/");
      return {
        get: function () {
          return fetch(url, {credentials: "same-origin", headers: H}).then(function (r) {
            if (r.status === 404) return {exists: false, data: function () { return undefined; }};
            if (!r.ok) return fail(r);
            return r.json().then(function (d) { return {exists: true, data: function () { return d; }}; });
          });
        },
        set: function (data) {
          return call(url, {method: "PUT", headers: {"Content-Type": "application/json"}, body: JSON.stringify(data)}).then(function () {});
        }
      };
    }
  };

  var assets = {
    upload: function (blob, o) {
      return call("/api/assets", {method: "POST", headers: {"Content-Type": (o && o.type) || blob.type || "application/octet-stream"}, body: blob})
        .then(function (r) { return r.json(); });
    },
    "delete": function (id) {
      return call("/api/assets/" + encodeURIComponent(id), {method: "DELETE"}).then(function () {});
    }
  };

  var user = {
    canEdit: function () {
      return fetch("/api/me", {credentials: "same-origin", headers: H}).then(function (r) { return r.ok ? r.json() : {}; })
        .then(function (j) { return !!j.admin; }, function () { return false; });
    }
  };

  var caps = {sample: sample, downloads: downloads, db: db, assets: assets, user: user};
  window.claude = {use: function (name) { return Promise.resolve(caps[name] || null); }};
})();
